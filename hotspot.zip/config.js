// External captive portal configuration
// Set your externally hosted portal base URL (no trailing slash)
// Example: https://hotspot.example.com
window.EXTERNAL_PORTAL_BASE = 'https://ispinnacle.co.ke';

// Optional: force an organization ID to pass as ?org=...
// Leave empty to let the portal use its own default/org detection
window.EXTERNAL_PORTAL_ORG = 'cmhceijtv00032o2joxig9dc8';

